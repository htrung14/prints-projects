<!-- BEGIN:nextjs-agent-rules -->
# This is NOT the Next.js you know

This version has breaking changes. APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` before writing any code. Heed deprecation notices.
<!-- END:nextjs-agent-rules -->

# Project-specific rules

Before making non-trivial changes, read `docs-ai/README.md` and
`docs/system-design.md`. Keep edits minimal. Never commit without
explicit user approval. No Co-Authored-By lines.

The sibling repo `prints-projects` carries the shared design system.
When in doubt about tokens, utilities, or patterns, read its
`src/app/globals.css` and its components.
