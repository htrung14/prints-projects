# docs-ai

Source of truth for AI agents working on this repo.

- Primary design doc: `../docs/system-design.md`. Read it before making
  any non-trivial change.
- Handoff plan that created this repo:
  `/Users/haivotrung/.claude/plans/adaptive-hopping-snowglobe.md` on the
  user's machine. Not checked in. Ask the user if you need it.
- Sibling repo: `prints-projects` (the print shop). Its `docs-ai/` and
  `docs/system-design.md` are the authoritative references for the
  shared design system. When in doubt, read the shop.

## Decisions locked (2026-04-15)

- Scope: minimum viable press kit, single page, placeholder content.
- Stack mirrors the shop: Next.js 16 App Router, React 19, TS strict,
  Tailwind v4 (tokens in `@theme inline`), Geist font, pnpm.
- `build` uses `next build --webpack`. Not Turbopack.
- Footer is the Loose-Joints-inspired contact panel (Element A in the
  handoff). Credit strip sits above it (Element B).
- Body copy stays in Geist. No serif variant for v1.
- Deploy target: `prints-press.vercel.app`.
- Repo-local git identity must be `haivo14@icloud.com` before first
  commit to avoid Vercel seat block.

## When adding work to this repo

1. Read `docs/system-design.md` first.
2. Match existing token usage. Do not introduce new colors or fonts
   without updating the tokens in `globals.css` and this doc.
3. Keep edits minimal. Do not refactor unrelated code.
4. Flag files larger than 250 lines or functions larger than 50 lines.
5. Never commit without explicit user approval. No Co-Authored-By lines.
