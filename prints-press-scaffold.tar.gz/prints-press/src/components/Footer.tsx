import Tbd from "./Tbd";

const SHOP_URL = "https://prints-projects.vercel.app";
const INSTAGRAM_URL = "https://instagram.com"; // TBD: real handle
const NEWSLETTER_MAILTO =
  "mailto:?subject=Subscribe%20to%20newsletter&body=Please%20add%20me%20to%20the%20Thalia%20Bassim%20newsletter.";

/*
  Contact-panel footer. Two-column split on md+, stacked on mobile.
  Left: identity + studio. Right: contact rows. Bottom rail: copyright
  and newsletter link.
  Inspired by editorial/publisher footers (Loose Joints et al.), but
  monochrome only, with our token palette. Structural pattern
  (label/value rows, email-as-primary-contact) is a common editorial
  convention, not a copy of any one site.
*/

type RowProps = {
  label: string;
  children: React.ReactNode;
};
function Row({ label, children }: RowProps) {
  return (
    <li className="flex items-baseline justify-between gap-4 py-2">
      <span className="label-caps">{label}</span>
      <span className="text-ink-strong text-right">{children}</span>
    </li>
  );
}

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer
      className="border-t bg-bg-soft px-6 pt-12 pb-8 md:px-10"
      style={{ borderTopColor: "var(--ink)" }}
    >
      <div className="grid gap-10 md:grid-cols-2 md:gap-16">
        {/* LEFT COLUMN: identity + studio */}
        <div>
          <div className="h-display text-ink-strong">Thalia Bassim</div>
          <div className="mt-1 text-ink">Photographer, Brooklyn, NY</div>

          <div className="mt-8 border-t border-ink-line pt-6">
            <div className="label-caps mb-2">Studio</div>
            <p className="leading-relaxed">
              Brooklyn, NY
              <br />
              By appointment
            </p>
            <p className="mt-3 text-ink-faint">
              <Tbd label="exact studio address if you want to publish it" />
            </p>
          </div>
        </div>

        {/* RIGHT COLUMN: contact rows */}
        <div>
          <ul className="divide-y divide-ink-line">
            <Row label="General">
              <a href="mailto:?subject=General%20inquiry">
                <Tbd label="general email" />
              </a>
            </Row>
            <Row label="Press">
              <a href="mailto:?subject=Press%20inquiry">
                <Tbd label="press email" />
              </a>
            </Row>
            <Row label="Sales">
              <a href="mailto:?subject=Print%20sales">
                <Tbd label="sales email" />
              </a>
            </Row>
          </ul>

          <ul className="mt-8 divide-y divide-ink-line border-t border-ink-line">
            <Row label="Instagram">
              <a
                href={INSTAGRAM_URL}
                rel="noreferrer noopener"
                target="_blank"
              >
                @<Tbd label="handle" /> ↗
              </a>
            </Row>
            <Row label="Shop">
              <a href={SHOP_URL} rel="noreferrer noopener" target="_blank">
                prints-projects.vercel.app ↗
              </a>
            </Row>
          </ul>
        </div>
      </div>

      {/* BOTTOM RAIL */}
      <div className="mt-12 flex flex-wrap items-baseline justify-between gap-3 border-t border-ink-line pt-6 text-ink-faint">
        <span>© {year} Thalia Bassim. All rights reserved.</span>
        <a href={NEWSLETTER_MAILTO} className="underline">
          Subscribe to newsletter ↗
        </a>
      </div>
    </footer>
  );
}
