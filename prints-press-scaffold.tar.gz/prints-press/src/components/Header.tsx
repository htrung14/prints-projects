import Link from "next/link";

const SHOP_URL = "https://prints-projects.vercel.app";

/**
 * Press-kit header. Deliberately simpler than the shop's three-group Cargo
 * layout: this is a "document header," not a storefront nav.
 *   LEFT   artist name + Press label
 *   RIGHT  single link back to the shop (opens new tab)
 * Sticky on scroll with a thin bottom rule. No cart, no essay, no Arabic mark.
 */
export default function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-ink-line bg-bg">
      <div className="flex items-baseline justify-between gap-6 px-6 py-5 md:px-10">
        <div className="flex items-baseline gap-2">
          <Link href="/" className="text-ink-strong">
            Thalia Bassim
          </Link>
          <span className="text-ink-faint">· Press</span>
        </div>

        <a
          href={SHOP_URL}
          rel="noreferrer noopener"
          target="_blank"
          className="text-ink-strong"
        >
          Return to shop ↗
        </a>
      </div>
    </header>
  );
}
