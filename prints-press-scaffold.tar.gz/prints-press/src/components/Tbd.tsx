/**
 * Placeholder marker. Wraps content the photographer still needs to supply,
 * so the press kit renders cleanly but the user can see, at a glance, what
 * is unfinished. Renders a dashed-border chip with the label inside.
 *
 * Usage:
 *   <Tbd label="press email" />
 *   <Tbd>contact@example.com (placeholder)</Tbd>
 */
type TbdProps =
  | { label: string; children?: never }
  | { label?: never; children: React.ReactNode };

export default function Tbd(props: TbdProps) {
  const content =
    "label" in props && props.label ? `TBD: ${props.label}` : props.children;
  return (
    <span className="tbd" data-tbd="true">
      {content}
    </span>
  );
}
