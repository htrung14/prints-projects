import Tbd from "@/components/Tbd";

const SHOP_URL = "https://prints-projects.vercel.app";

/*
  Press kit landing. Single page, five sections, numbered rail.
  All content is placeholder; the user will replace it. Placeholder bodies
  are wrapped in <Tbd /> so the draft state is visible on the page itself.
*/

function Section({
  id,
  num,
  title,
  children,
}: {
  id: string;
  num: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section
      id={id}
      className="section-rail border-t border-ink-line px-6 py-16 md:px-10 md:py-20"
    >
      <div className="section-rail-num">
        {num} · <span className="text-ink">{title.toUpperCase()}</span>
      </div>
      <div className="max-w-[68ch]">{children}</div>
    </section>
  );
}

function CvRow({ year, description }: { year: string; description: string }) {
  return (
    <li className="grid grid-cols-[72px_1fr] items-baseline gap-4 border-b border-ink-line py-3">
      <span className="text-ink-faint tabular-nums">{year}</span>
      <span className="text-ink">
        <Tbd label={description} />
      </span>
    </li>
  );
}

export default function Page() {
  return (
    <>
      {/* HERO */}
      <section className="px-6 pt-16 pb-20 md:px-10 md:pt-24 md:pb-28">
        <div className="label-caps mb-6">Press kit · Draft</div>
        <h1 className="h-display-xl">
          Thalia <em>Bassim</em>
        </h1>
        <p className="mt-6 max-w-[52ch] text-ink">
          Photographer based in Brooklyn, New York. Prints, editions, and
          selected press.
        </p>
        <p className="mt-4 max-w-[52ch] text-ink-faint">
          <Tbd label="one-line tagline from Thalia (what the work is about, in her voice)" />
        </p>
      </section>

      {/* 01 BIO */}
      <Section id="bio" num="01" title="Bio">
        <p className="drop-cap leading-relaxed">
          <Tbd label="opening paragraph of the bio, roughly 150 to 250 words, in Thalia's voice. Covers where she is from, what she photographs, and the medium" />
        </p>
        <p className="mt-6 leading-relaxed">
          <Tbd label="second paragraph, roughly 150 to 250 words. Covers influences, current practice, recurring subjects" />
        </p>
        <p className="mt-6 leading-relaxed">
          <Tbd label="third paragraph, roughly 100 to 200 words. Covers recent or upcoming work, exhibitions, or publications" />
        </p>
      </Section>

      {/* 02 CV */}
      <Section id="cv" num="02" title="CV">
        <p className="mb-6 text-ink-faint">
          Selected. Years are approximate until the photographer confirms.
        </p>
        <ul className="border-t border-ink-line">
          <CvRow
            year="2024"
            description="solo exhibition title, venue, city"
          />
          <CvRow year="2024" description="group show title, venue, city" />
          <CvRow
            year="2023"
            description="publication title, publisher, year"
          />
          <CvRow year="2023" description="group show title, venue, city" />
          <CvRow year="2022" description="residency or award, institution" />
          <CvRow
            year="2022"
            description="solo exhibition title, venue, city"
          />
          <CvRow year="2021" description="print commission, client" />
          <CvRow year="2020" description="group show title, venue, city" />
          <CvRow
            year="2019"
            description="first significant publication or show"
          />
          <CvRow year="2018" description="MFA or educational milestone" />
        </ul>
        <p className="mt-6 text-ink-faint">
          Full CV on request. Contact <Tbd label="press email" /> for a PDF.
        </p>
      </Section>

      {/* 03 PRESS */}
      <Section id="press" num="03" title="Press">
        <p className="leading-relaxed">
          For interviews, high-resolution press images, or a biography PDF,
          contact <Tbd label="press email" />. Response time is typically
          within five working days.
        </p>
        <p className="mt-4 leading-relaxed text-ink-faint">
          Downloadable press kit (biography, headshot, selected images) is
          planned but not available in this draft.
        </p>
      </Section>

      {/* 04 CONTACT */}
      <Section id="contact" num="04" title="Contact">
        <p className="leading-relaxed">
          See the footer below for direct email addresses, studio location,
          and social links. For prints and editions, visit the shop at{" "}
          <a
            href={SHOP_URL}
            rel="noreferrer noopener"
            target="_blank"
            className="text-ink-strong underline"
          >
            prints-projects.vercel.app
          </a>
          .
        </p>
      </Section>

      {/* CREDIT STRIP (Element B) */}
      <div className="border-t border-ink-line px-6 py-6 text-xs text-ink-faint md:px-10">
        <span>
          Last updated April 15, 2026. Press kit draft. Web development:{" "}
          <Tbd label="web dev credit name" /> · Typeface: Geist by Vercel ·
          Photography: Thalia Bassim · Film processing and scan: PhotoLife,
          Brooklyn
        </span>
      </div>
    </>
  );
}
