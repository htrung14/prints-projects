# prints-press system design (v0.1)

> Sister site to `prints-projects` (the print shop). Serves as Thalia
> Bassim's press kit: bio, CV, press contact, link back to the shop.
> This document is the source of truth for the design decisions locked on
> 2026-04-15. Update it if decisions change.

## Purpose

Single-page press kit. Not a blog, not a portfolio, not a full site.
Minimum viable scope:

- Hero with artist name and one-line tagline
- Bio (three-paragraph placeholder)
- Selected CV (two-column year / description, ~10 rows)
- Press contact stub
- Contact section that points to the footer
- Contact-panel footer with General / Press / Sales email rows
- Credit strip above the footer

Out of scope for v1: downloads (press PDF, headshot), news feed, separate
routes per section, portfolio grid, newsletter signup backend.

## Stack

- Next.js 16.2.3 App Router
- React 19.2.4
- TypeScript strict
- Tailwind CSS v4 (tokens in `@theme inline` in `globals.css`, no
  `tailwind.config.*`)
- Geist font via `next/font/google`, weights 400 / 700 / 900
- pnpm

### Critical build settings

- `build` script uses `next build --webpack`, NOT Turbopack. Turbopack
  emits chunk filenames with `..`, `~`, `--` that some corporate content
  filters block. Mirrored from the shop.
- ESLint disables `@next/next/no-img-element` (mirrors shop).

## Design tokens

Mirrored from the shop. Declared in `:root`, exposed as Tailwind utilities
via `@theme inline`:

- `--bg` `#ffffff`
- `--bg-soft` `#f4f4f0`
- `--ink` `rgba(0,0,0,0.78)`
- `--ink-strong` `rgba(0,0,0,0.95)`
- `--ink-line` `rgba(0,0,0,0.18)`
- `--ink-faint` `rgba(0,0,0,0.5)`

Utilities in use: `bg-bg`, `bg-bg-soft`, `text-ink`, `text-ink-strong`,
`text-ink-faint`, `border-ink-line`, `divide-ink-line`.

Typographic utility classes: `.h-display`, `.h-display-xl`, `.label-caps`,
`.drop-cap`, and press-kit-specific `.section-rail` + `.section-rail-num`.

## Visual relationship to the shop

Same palette and typeface, but this site reads as a document, not a
storefront. Differences from the shop:

- Header is two-group (name + Return to shop), not three-group Cargo
  layout. No cart, no essay, no Arabic mark.
- Footer is a two-column contact panel with three labeled email rows,
  internal rules, and a bottom rail. Shop footer is four columns.
- Content uses numbered-section rails (`01 · BIO`, `02 · CV`...).

## Design inspiration note

The footer structure (two-column split, label/value rows,
email-as-primary-contact, internal rules between sections) is drawn from
editorial and publisher conventions, with reference to Loose Joints.
Differences that keep this from being a copy:

- Monochrome only. No green/red accent panels.
- Three email categories (General, Press, Sales), not four.
- One address (Brooklyn), not two.
- No branded pill buttons.
- Our token palette, our type.

## File layout

```
prints-press/
  .husky/pre-commit             # pnpm lint-staged && pnpm typecheck
  .nvmrc                        # 20
  .prettierrc.json
  .prettierignore
  .env.example                  # empty, reserved for future secrets
  docs/
    system-design.md            # this file
  docs-ai/
    README.md                   # pointer back to the handoff + design lock
  public/                       # favicons etc.
  src/
    app/
      layout.tsx                # root layout, Geist font, Header + Footer
      page.tsx                  # press kit page (5 sections + credit strip)
      globals.css               # tokens + utilities
      favicon.ico
    components/
      Header.tsx                # name + Return to shop
      Footer.tsx                # contact panel (Element A)
      Tbd.tsx                   # dashed placeholder chip
  eslint.config.mjs
  next.config.ts
  package.json                  # "build": "next build --webpack"
  postcss.config.mjs
  tsconfig.json
```

## Open items (things Thalia needs to supply)

- Real bio copy (three paragraphs)
- Portrait photo (optional)
- Real CV entries (years + descriptions)
- Real contact emails: General, Press, Sales
- Instagram handle URL
- Studio address if it differs from "Brooklyn, NY · by appointment"
- Web developer credit name
- Newsletter signup target (mailto vs. real service)

All of these render as `<Tbd label="..." />` chips on the page so they
are visible on review.

## Deployment

Follow the handoff plan steps 14 through 21:

1. `git init -b main`
2. Set repo-local git identity: `user.email haivo14@icloud.com`,
   `user.name "Hai Vo"`. Required to avoid the Vercel TEAM_ACCESS_REQUIRED
   seat block that hit the shop.
3. First commit (ask before bypassing GPG signing if 1Password agent is
   not running).
4. `gh repo create prints-press --private --source=. --push`
5. `vercel link --yes --project prints-press`
6. `vercel deploy --yes`
7. Hand over the short alias URL, not the long auto-generated one. The
   long form is SSO-gated by Vercel Deployment Protection.

## Known gotchas (inherited from shop)

1. Tailwind v4 arbitrary-value syntax (`bg-[var(--ink-strong)]`) is
   unreliable. Use theme-token utilities (`bg-ink-strong`).
2. Anchor-based filled buttons render dark-on-dark due to an interaction
   between Next `<Link>` and Tailwind base styles. If you add one, use an
   inline style: `style={{ backgroundColor: "var(--ink-strong)", color:
   "var(--bg)" }}`. Plain `<button>` is fine with classes alone.
3. Vercel CLI uses device-code browser flow for login. Surface the URL
   and code and wait.
4. `next build --webpack` is the required build command. Do not switch to
   Turbopack without testing the chunk-filename issue.
5. 1Password SSH signing must be running for signed commits. Bypass with
   `-c commit.gpgsign=false` only with explicit user approval.
