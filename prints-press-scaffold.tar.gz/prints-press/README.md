# prints-press

Press kit for Thalia Bassim. Sister site to
[`prints-projects`](https://github.com/htrung14/prints-projects) (the print
shop).

Single-page static site covering bio, CV, press contact, and a link back
to the shop.

## Stack

- Next.js 16 App Router, React 19, TypeScript strict
- Tailwind CSS v4 (tokens in `@theme inline` in `src/app/globals.css`)
- Geist font via `next/font/google`
- pnpm

## Setup

```bash
nvm use              # Node 20
pnpm install
pnpm dev             # http://localhost:3000
```

## Scripts

- `pnpm dev`: dev server
- `pnpm build`: production build (uses webpack, not Turbopack; see
  `docs/system-design.md` for the reason)
- `pnpm start`: serve the production build
- `pnpm lint`: ESLint
- `pnpm typecheck`: tsc noEmit
- `pnpm format`: Prettier write
- `pnpm format:check`: Prettier check

Pre-commit runs `lint-staged` + `typecheck` via Husky.

## Layout

```
src/
  app/
    layout.tsx        # root layout, Geist font, Header + Footer
    page.tsx          # press kit page (5 sections + credit strip)
    globals.css       # tokens + utilities
  components/
    Header.tsx        # name + Return to shop
    Footer.tsx        # contact panel (General / Press / Sales rows)
    Tbd.tsx           # dashed placeholder chip
```

## What is placeholder

Everything wrapped in a `<Tbd label="..." />` chip is unfinished. The chip
renders a dashed border so draft state is visible on the page itself.
Replace each one as real content lands.

Open items (tracked in `docs/system-design.md`):

- Bio copy, portrait photo
- CV rows
- Real email addresses (General, Press, Sales)
- Instagram handle
- Web developer credit

## Deployment

Vercel project `prints-press`. Short alias: `prints-press.vercel.app`.
See `docs/system-design.md` for the full deploy flow.

## Sibling

The shop at
[prints-projects.vercel.app](https://prints-projects.vercel.app) is the
sibling site. They share a design system; changes to tokens or shared
patterns should happen in both.
